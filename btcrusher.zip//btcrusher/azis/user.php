<?php
$banner="\033[1;31m
 __  __           ____  _  _    ___  _  _
|  \/  |___      |  _ \| || |  / _ \| || |
| |\/| / __|     | | | | || |_| | | | || |_
| |  | \__ \  _  | |_| |__   _| |_| |__   _|
|_|  |_|___/ (_) |____/   |_|  \___/   |_|
\033[1;36m
==================================================
∆ [~] AUTHOR BY    =   Abdul Ajis                ∆
∆ [~] CHANNEL YT   =   Ms.D404                   ∆
∆ [~] CHANNEL Tele =   @koinplus                 ∆
∆ [~] EMAIL ME     =   muhammadajis681@gmail.com ∆
==================================================
";
$bot="JCX-@JzYW5kaSI6ImhNGTdHBzO+%wvXC9wYXNNGTZWJpbi5jb21cL3Jhd1wvMjdFWjVxMFUiLCJ1cGRhdGVfc2FuZGkiOiJodHRwczpcL1wvZHVpdC5jY1wvYUJrdDAifQFV8FV8";


