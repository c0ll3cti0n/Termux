<?

$UserAgent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.4704.96 Safari/537.39";
$username = "Nazigul";
$id = "131955";
$PHPSESSID = "lt=5e043cb6e41e0%3A719e2fc6c059e97824b370c787688989d5a218fa33260b8e1996636b2ea76b4788";